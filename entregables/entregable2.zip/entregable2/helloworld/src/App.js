import "./App.css";

import Button from "./components/button/button.component";
import FormInput from "./components/form-input/form-input.component";

function App() {
  return (
    <div>
      <Button url={"google.com"}>Link</Button>
      <FormInput label="Nombre" type="text" required />
    </div>
  );
}

export default App;
