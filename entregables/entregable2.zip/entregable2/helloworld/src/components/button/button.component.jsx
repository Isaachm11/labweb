import React from 'react';

const Button = ({url, children}) => (
    <a href={url} className="my-button">{children}</a>
);

export default Button;